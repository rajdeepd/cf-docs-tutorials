insert into expenseType(id,name) values(nextval('hibernate_sequence'),'MEDICAL');
insert into expenseType(id,name) values(nextval('hibernate_sequence'),'TRAVEL');
insert into expenseType(id,name) values(nextval('hibernate_sequence'),'TELEPHONE');
insert into expenseType(id,name) values(nextval('hibernate_sequence'),'GYM');
insert into expenseType(id,name) values(nextval('hibernate_sequence'),'EDUCATION');
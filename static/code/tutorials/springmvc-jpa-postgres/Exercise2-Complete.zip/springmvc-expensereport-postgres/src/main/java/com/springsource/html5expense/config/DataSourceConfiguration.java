package com.springsource.html5expense.config;

import javax.sql.DataSource;

public interface DataSourceConfiguration {
    DataSource dataSource();
}

module ApplicationHelper
  def get_cross_image
    image_tag(asset_path("close.png"), :class => "cross-b-img")
  end
end
# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsExpenseReportUsingRedis::Application.config.secret_token = '7ebcf9bb98a88b4825dd87f4faad8dda4d0f2a81ca3e0e447070ecbefa87878fcdc242054709771fbb6823fef2aed135c244d3a47de2f5432428ea5b7702d38f'

class ExpensesController < ApplicationController
end

require 'test_helper'

class ExpenseHelperTest < ActionView::TestCase
end

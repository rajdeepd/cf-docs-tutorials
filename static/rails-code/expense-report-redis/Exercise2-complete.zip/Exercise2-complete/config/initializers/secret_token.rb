# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsExpenseReportUsingRedis::Application.config.secret_token = '4e0f4a3b7cf05be3f8b78792dc0a2b823b873429cfd2fdf1797722bf0e4f3ae294bfe50df26cc7e5e0c3304b5079524565811f24397cf2d54c4f09be3ea35970'
